export default [
    {
        name: 'Elon Musk',
        userName: '@elonmusk',
        time: '23h',
        title: 'Amazing show about @inspiration4x mission!',
        userImage:'musk.jpeg',
        image: 'spaceman.jpeg',
        comments: '4.2k',
        retweet:'3.5k',
        head_content:'Contrary to popular belief, Lorem Ipsum is not simply random text...',
        content:'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.',
        likes:'37.5k'

    },
    {
        name: 'New York Post',
        userName: '@nypost',
        time: '23h',
        title: "Grimes seen reading Karl Max following split with world's richest man Elon Musk",
        userImage:'nyp.png',
        image: 'grimes.jpeg',
        comments: '965',
        retweet:'2.4k',
        head_content:'',
        content:'',
        likes:'4k'
    },
];
 